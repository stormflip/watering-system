# Intelligent-Irrigation-System
This is a repository of samrt irrigation system..
